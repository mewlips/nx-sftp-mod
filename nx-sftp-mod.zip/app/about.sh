#!/bin/bash

source /opt/usr/apps/nx-sftp-mod/common.sh

about="[[ nx-sftp-mod v0.9 ]]<br><br>"
about="${about}Copyright (C) 2016<br>Mewlips (mewlips@gmail.com)<br>"
about="${about}https://github.com/mewlips/nx-sftp-mod<br><br>"
about="${about}The GNU General Public License v3.0<br>"
about="${about}https://www.gnu.org/licenses/gpl-3.0.html"
popup_back_or_close "$about"
